/*Question-1 File operations program that demonstrates copying of data from input file and write into output file, until reaches end of file data.*/

#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>
#include<string.h>

void main()
{
	
	char Rbuff[1000];
	
	int fd1 = open("hello_Input.txt", O_RDONLY, 777);			
	int fd2 = open("file_Output.txt",O_RDWR, 777);			 
	int len;
	
	
	read(fd1, Rbuff, 200);   //read
	
	printf("data read = %s\n",Rbuff);
	
	
	len = write(fd2, Rbuff, 200);  //write
	
	printf("data written = %d \n", len);
	
	
	
	close(fd2);
	close(fd1);
	
}

/* Question - 3 Program Returning “ls -l ” kind of structure of information from an existing file or opend file. */

#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

int main()
{
		
	char file[20];
	
	
	printf("Enter the name of file in the fromat(name.extension): ");
	scanf("%s", file);
	
	printf("ls -l is\n");
	execl("/bin/ls", "ls", "-l", file, 0); //ls -s Operation
	
	return 0;
}

/* Question -2 Program to demonstrate repositioning of file offset using SEEK_SET, SEEK_CUR and SEEK_END.*/

#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

int main()
{
	int fd1, fd2, fd3;
	int len=0;


	char wbuff[] = "\nVM5  data Writing to write.txt file\n";

	
	
	fd1 = open("write.txt", O_CREAT | O_RDWR, 0666); //write
	len = fwrite(fd1 , wbuff, sizeof(wbuff));
	printf("File descriptor fd1 : %d\nD ata written length is: %d\n",fd1,len);


	lseek(fd1, 0, SEEK_SET);		//set cursor to beginning


	char rbuff[len];

	
	
	read(fd1, rbuff, len); //read from write.txt
	printf("File contents are: %s",rbuff);
	close(fd1);


	int length=0;
	char buffer[]="SEEK_SET, SEEK_CUR, SEEK_END";
	int curr=0;


	curr = lseek(fd1, 0, SEEK_CUR);
	printf("Current position of file: %d\n",curr);


	fd2 = open("write.txt", O_RDWR, 0666);
	lseek(fd2, 0, SEEK_END);


	length = write(fd2 , buffer, sizeof(buffer));
	printf("File descriptor returned by fd2 is: %d and data written length: %d\n",fd1,length);


	lseek(fd2, len, SEEK_SET);
	char buffer1[length];


	read(fd2, buffer1, length);
	printf("The Content of files are: %s\n",buffer1);


	close(fd2);


	return 0;
}

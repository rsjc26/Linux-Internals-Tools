/* Question - 4 Program implementing all file operations(open/creat/write/read/lseek/close)*/

#include<stdio.h>
#include<fcntl.h>
#include<unistd.h>

void main()
{
	int fd1, fd2;
	char rbuff[100];
	int len;
	
	fd1 = creat("hello.txt", 0777);		//create a file
		
	fd2 = open("main.txt.txt", O_RDONLY, 777);		//open main.txt existing file	
	
	len = read(fd2, rbuff, 60);				
	printf("Print content of main.txt -\n%s\n",rbuff);	
	
	//write to hello.txt
	len = write(fd1, rbuff, 60);			
	
	printf("The printed data in hello.txt is:\n");
	
	lseek(fd2, 5, SEEK_SET);			
	read(fd2, rbuff, 50);
	printf("After performing lseek operation is = %s\n",rbuff);
	
	close(fd2);
	close(fd1);
}

//Question:4:Write a program which get and set pthread scheduling policy and priority.

#include<stdio.h>
#include<string.h>
#include<pthread.h>
#include<stdlib.h>


int main()
{
	pthread_t fun_tid;

	struct sched_param fun_pr;

	int policy;

	pthread_getschedparam(pthread_self(), &policy, &fun_pr);
	printf("Default setting: \n\npolicy: %d \npriority: %d\n",policy, fun_pr.sched_priority);

	policy = SCHED_FIFO;
	fun_pr.sched_priority = 8;

	pthread_setschedparam(pthread_self(), policy, &fun_pr);

	pthread_getschedparam(pthread_self(), &policy, &fun_pr);
	printf("\nAfter Setting: \n\npolicy: %d \npriority: %d\n",policy, fun_pr.sched_priority);

	return 0;
}

//Ques-1.Write a pthread application where main task terminated but pending pthreads task still execute.


#include<stdio.h>
#include<string.h>
#include<pthread.h>

void *fun(void *arg)
{

	for(int i=0; i<5; i++)
	{
		printf("Execute the thread functiom : %d\n",i);
	}

	printf("Exit the thread\n");
}

int main()
{
    //Cmmd to generate thread Id
	pthread_t f_t_id;
	
	pthread_create(&f_t_id, NULL, fun, NULL);

	pthread_join(f_t_id, NULL);

	pthread_exit(NULL);  
	printf("Exit the main thread\n");

	return 0;
}

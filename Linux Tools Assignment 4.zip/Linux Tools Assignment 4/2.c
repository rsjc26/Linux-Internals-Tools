//Ques-2.Write a program where a structure of information passed to pthread task function, and display structure of information.

#include<stdio.h>
#include<string.h>
#include<pthread.h>
#include<stdlib.h>

struct student
{
	int Roll_No;
	char name[50];
	int Marks;
};

void *fun(void *args)
{
	struct student *s = (struct student *)args;

	printf("Roll_No: %d\nName: %s\nMarks: %d\n",s->Roll_No, s->name, s->Marks);

	return NULL;
}

int main()
{
	struct student S;

	pthread_t f_tid;

	S.Roll_No = 26;
	strcpy(S.name, "Hierath");
	S.Marks = 89;

	pthread_create(&f_tid, NULL, fun, &S);
	pthread_join(f_tid, NULL);

	pthread_exit(NULL);

	return 0;
}

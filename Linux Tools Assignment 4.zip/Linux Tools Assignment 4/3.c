//Ques:3. Write a pthread program that implements simple initialization code.

#include<stdio.h>
#include<string.h>
#include<pthread.h>
#include<stdlib.h>


pthread_once_t once_code = PTHREAD_ONCE_INIT;

void *fun()
{
	printf("Code Initialization \n");
}

void *fun_task(void *args)
{
	printf("In thread %d\n",(int *)args);
	
	pthread_once(&once_code , (void *)fun);

	printf("Exit the thread %d\n", (int *)args);

	return NULL;
}

int main()
{
	pthread_t fun_id1, fun_id2, fun_id3;

	pthread_create(&fun_id1, NULL, fun_task, (void *)1);
	pthread_create(&fun_id2, NULL, fun_task, (void *)2);
	pthread_create(&fun_id3, NULL, fun_task, (void *)3);

	pthread_join(fun_id1, NULL);
	pthread_join(fun_id2, NULL);
	pthread_join(fun_id3, NULL);

	return 0;
}
